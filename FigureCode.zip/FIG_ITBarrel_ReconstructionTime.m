function FIG_ITBarrel_ReconstructionTime(varargin)
  
%% PARSE ARGUMENTS
P = parsePairs(varargin);
checkField(P,'FIG',1); checkField(P,'Save',1);  checkField(P,'View',0);  checkField(P,'Recompute',0);  

% SETUP BASICS
Dirs = setgetDirs; cDir = Dirs.ITBarrel;
setPlotOpt('neuron','path',cDir,'cols',1,'height',14.5); 
Sep = HF_getSep;

if P.Recompute  LF_generateData(P.Recompute,inpath,name); end; load([inpath,name]);

% PREPARE FIGURE
figure(P.FIG); clf; set(P.FIG,FigOpt{:}); HF_matchAspectRatio;
DC1= axesDivide(1,[0.7,3],[0.12,0.06,0.75,0.9],[],[0.6]);
DC2= axesDivide([1,1.5],3,DC1{2},[1],[0.6]);
DC = [DC1(1);DC2(:)];
Labels = {'A','B','C','D'}; LdPos = [-0.08,-0.0];
for i = 1:numel(DC)
  AH(i) = axes('Pos',DC{i}); hold on;
  if i<=4 FigLabel(Labels{i},LdPos); end
end
HF_setFigProps;

% START PLOTTING 
CellTypes = {'Excitatory','Inhibitory'};
ColorsByNeuron = struct('Excitatory',[1,0,0],'Inhibitory',[0,0,1]);
MarkerSize = 4; LineWidth = 1.5;
CM = HF_colormap({[0,0,1],[1,1,1],[1,0,0]},[-1,0,1]);
colormap([1,1,1;CM]); iA = 1;

% DISPLAY INTRODUCTORY FIGURE WITH A RASTER
axes(AH(iA)); iA = iA+1; Offset = 0;
for iT = 1:length(CellTypes)
  cType = CellTypes{iT};
  cSpikeTimes = R.(cType).SpiketimesByTrial;
  cInd = find(cSpikeTimes>0); [iX,iY] = find(cSpikeTimes>0);
  plot(cSpikeTimes(cInd),iX + Offset,'.',...
    'Color',ColorsByNeuron.(cType),'LineWidth',0.5,'MarkerSize',MarkerSize);
  Offset = Offset + max(iX);
end
xlabel('Time (ms)');
ylabel('Neurons');
axis([0,40,0,Offset]);
set(gca,'XTick',[0:10:50],'ytick',[]);

% START DISPLAYING DATA
PlotTypes = {'Time','TimeNumber'};
XLabels = {'Time (ms)','Time (ms)'};
YLabels = {'MI (bits)','Neurons (#)'};
CLabels = {'','\Delta_{E-I} MI (bits)'};
GroupInd = 10;
BinSizeInd = 2; cBinSize = R.BinSize(BinSizeInd)*1000;
% Special Chao Note: Analysis starts at 10ms
Time = 10+[cBinSize/2:cBinSize:cBinSize * (R.NTimes-1/2)];
PreTime = fliplr(Time(1)-cBinSize:-cBinSize:0);
Time = [PreTime,Time];
GroupSizes = R.Groups;
for iP=1:length(PlotTypes)
  for iC = 1:length(R.Conditions)
    axes(AH(iA)); iA = iA +1;
    cCondition = R.Conditions{iC};
    cData = R.(cCondition);
    switch PlotTypes{iP}
      case 'Time';
        plot([0,100],[2,2],'Color',[0.5,0.5,0.5]);
        for iT=1:length(CellTypes)
          cType = CellTypes{iT};
          ccData = squeeze(cData.(cType)(GroupInd,BinSizeInd,:,:));
          Tmp = ccData; Tmp(Tmp==0) = NaN; ccData(3:end,:) = Tmp(3:end,:);
          cColor = ColorsByNeuron.(cType);
          plot(Time,[zeros(size(PreTime))';nanmean(ccData,2)],'-','Color',cColor,'LineWidth',LineWidth);
          if iC == 1
            text(1,0.72-(iT-1)*0.13,CellTypes{iT},'Units','n','Horiz','r','Color',cColor,'FontWeight','bold','FontSize',6);
          end
        end
        if iC == 2 text(1,0.1,['N_{group} = ',n2s(GroupInd)],'Units','n','Horiz','r',TextOpt{:}); end
        axis([0,40,0,2.5]);  set(gca,'YTick',[0,1,2]);
        
      case 'TimeNumber';
        ccData = cData.Excitatory - cData.Inhibitory;
        ccData = squeeze(nanmean(ccData(:,BinSizeInd,:,:),4)); % Groups X Time
        for iT = 1:size(ccData,1)
          cPos = find(ccData(iT,end:-1:1)~=0,1,'first');
          ccData(iT,end-cPos+1:end) = ccData(iT,end-cPos);
        end
        GroupSizesAll = [1:GroupSizes(end)];
        PreStimMat = zeros(length(GroupSizes),length(PreTime));
        ccData = [PreStimMat,ccData];
        [GroupSizesM,TimeM] = meshgrid(GroupSizes,Time);
        [GroupSizesAllM,TimeAllM] = meshgrid(GroupSizesAll,Time);
        ccDataAll = interp2(GroupSizesM,TimeM,ccData,GroupSizesAllM,TimeAllM,'spline');
        imagesc(Time,GroupSizesAll,[PreStimMat,ccDataAll]);
        %imagesc(Time,GroupSizes,[zeros(length(GroupSizes),length(PreTime)),ccData]);
        caxis([-1.4,1.4]);
        h = colorbar; set(h,'YTick',[-1,0,1])
        h=text(1.9,0.5,CLabels{iP},'Units','n','Rotation',90,'Horiz','c',AxisLabelOpt{:});
        axis([-0.2,40,0,GroupSizes(end)+1]);
    end
    if iC == length(R.Conditions) xlabel(XLabels{iP}); end;
    ylabel(YLabels{iP});
  end
end
HF_setFigProps;

% SAVE FIGURES
HF_viewsave('path',outpath,'name',[name],'view',P.View,'save',P.Save,'format','pdf','res',600);

function LF_generateData(Recompute,inpath,name)
  
Dirs = setgetDirs; Sep = HF_getSep;

R.Conditions = {'DRate_DTime','DRate_FTime','FRate_FTime'};
Vars = {'MI_E_tm','MI_I_tm'}; VarMatch = struct('MI_E_tm','Excitatory','MI_I_tm','Inhibitory');
for iC = 1:length(R.Conditions)
  cCondition = R.Conditions{iC};

  % LOAD MIs
  BasePath = [Dirs.ITBarrel,'Data',Sep,'Coding_',cCondition,Sep];
  cFileName = [BasePath,'Coding_',cCondition,'_1-100_classify_1stspike_SVM.mat'];
  tmp = load(cFileName,Vars{:},'binsize','Cell_N');
  
  R.NMethods = size(tmp.(Vars{1}){1},1);
  R.NBinSizes = size(tmp.(Vars{1}){1},2);
  R.NTimes = size(tmp.(Vars{1}){1},3);
  R.NSamples = size(tmp.(Vars{1}){1},4);
  R.Groups = tmp.Cell_N; R.NGroups = length(R.Groups);
  R.BinSize = tmp.binsize;
  R.MethodInd = 1;

  for iV=1:length(Vars) % Loop over Variables
    for iG = 1:R.NGroups % Loop over Groupsizes
      R.(R.Conditions{iC}).(VarMatch.(Vars{iV}))(iG,:,:,:) = tmp.(Vars{iV}){iG}(R.MethodInd,:,:,:);
    end
  end  
 
  Conditions = {'DRate_DTime'};
  for iC = 1:length(Conditions)
    cCondition = Conditions{iC};
    BasePath = [Dirs.ITBarrel,'Data',Sep,'Coding_',cCondition,Sep];
    
    % LOAD OTHER INFO
    cFileName = [BasePath,'Coding_',cCondition,'_allparameters.mat'];
    tmp = load(cFileName,'l23info','lp','fpE','l23spt_A_con');
    R.IL23 = tmp.l23info;
    R.ITrials = tmp.fpE;
    R.AL23 = tmp.l23spt_A_con;
    IndEx = R.IL23(:,4)==1;
    IndInh = R.IL23(:,4)>1;
    Stimuli = R.ITrials(:,2); UStimuli = unique(Stimuli); R.NStimuli = length(UStimuli);
    SelTrialInd = 101;
    for iS = 1:R.NStimuli
      cStimulus = UStimuli(iS);
      R.Excitatory.SpiketimesByTrial = R.AL23{201}(IndEx,:)-40;
      R.Inhibitory.SpiketimesByTrial = R.AL23{201}(IndInh,:)-40;
    end
  end
end
save([inpath,name],'R')
