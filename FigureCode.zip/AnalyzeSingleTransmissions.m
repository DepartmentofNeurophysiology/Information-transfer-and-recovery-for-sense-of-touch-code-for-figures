function AnalyzeSingleTransmissions(varargin)
%% PARSE ARGUMENTS
P = parsePairs(varargin);
checkField(P,'View',0);  
checkField(P,'Save',1);  
checkField(P,'Source','invitro');
checkField(P,'State','allstates');
checkField(P,'Type','Ex');
checkField(P,'FIG',1);

% SETUP BASICS
Dirs = setgetDirs; cDir = Dirs.ITBarrel;
setPlotOpt('neuron','path',cDir,'width',13,'height',3.5); 
Name = ['SingleCellTiming_',P.Source,'_',P.Type]; Sep = HF_getSep;

% LOAD DATA
DataPath = [cDir,'Data',Sep];
R = load([DataPath,'SStOt_',P.Source,'_',P.Type,'.mat']);
switch P.Source
  case 'invitro';  YTickLabels.invitro = {'S1','S2','S3','S4'};
  case 'invivo';   YTickLabels.invivo = R.s_str;  
  case 'insilico';  YTickLabels.insilico = {'S1','S2','S3','S4','S5'};
    R.Ot = R.(['Ot_',P.State]); R.St = R.(['St_',P.State])-40;
  otherwise error('Source not implemented.');
end

% PREPARE FIGURE
figure(P.FIG); clf; set(P.FIG,FigOpt{:}); HF_matchAspectRatio;
[DC,AH] = axesDivide([1,1,1.6],1,[0.1,0.24,0.9,0.7],[0.3,0.4],[],'c'); 
Marker = '.'; MarkerSize = 8; LineWidth = 2;

% START PLOTTING 
Stimuli = unique(R.S);
Conditions = {{'Ot','S'},{'St','S'},{'St','Ot'}};
ColorsByStimulus ={[0.1,1,0.8],[0.2,1,0.8],[0.3,1,0.8],[0.45,1,0.8],[0.55,1,0.8]};
for i=1:length(ColorsByStimulus) ColorsByStimulus{i} = hsv2rgb(ColorsByStimulus{i}); end
MAX = 0;
Bins = [0:1:70];
Scaling = [0.7,0.4,0.15];
XLabels = {'Onset time (ms)','Spike time (ms)','Spike time (ms)'};
YLabels = {'Stimulus','Stimulus','Onset time (ms)'};

% SORT INSILICO RESPONSES 
switch P.Source
  case 'insilico';
    for iS=1:length(Stimuli)
      cInds{iS} = find(R.S==iS);
      cMean(iS) = mean(R.Ot(cInds{iS}));
    end
    [cInd,SortInd] = sort(cMean);
    cInds = cInds(SortInd);
    cInd = cell2mat(cInds);
    R.Ot = R.Ot(cInd);
    R.St = R.St(cInd);
end

for iC = 1:length(Conditions)
  axes(AH(iC)); set(AH(iC),AxisOpt{:}); hold on;
  if iC == 3 axis square; end
  fprintf([Conditions{iC}{1},': \n']);
  cTitle = [Conditions{iC},];
  for iS =1:4%length(Stimuli)
    cInd = find(R.S==iS);
    cX = R.(Conditions{iC}{1})(cInd);
    cY = R.(Conditions{iC}{2})(cInd);
    
    cInd = cX>0;
    cX = cX(cInd); cY = cY(cInd);

%     if iC<3
%       fprintf(['Stim: ',YTickLabels.invitro{iS},' : <X> = ',n2s(mean(cX)),' (+/- ',n2s(std(cX)),')\n']);
%     else
%       fprintf(['Stim: ',YTickLabels.invitro{iS},' : <X-Y> = ',n2s(mean(cX-cY)),' (+/- ',n2s(std(cX-cY)),')\n']);      
%     end
    MAX = max([MAX;cX;cY]);
    % PLOT DATA
    rand('seed',1);
    plot(cX,cY+(rand(size(cY))-0.5)/5+0.5*(iC<3),Marker,'Color',ColorsByStimulus{iS},'MarkerSize',MarkerSize);
    
    % PLOT X HISTOGRAM
    [H,B] = hist(cX,Bins);
    H = H/sum(H)/Scaling(iC);
    cInd = find(H>0); if ~isempty(cInd) cInd = [cInd(1)-1:cInd(end)+1]; end
    plot(B(cInd),H(cInd),'Color',ColorsByStimulus{iS},'LineWidth',LineWidth);
    
    if iC==3
      % PLOT Y HISTOGRAM
      [H,B] = hist(cY,Bins);
      H = H/sum(H)/Scaling(iC);
      cInd = find(H>0); if ~isempty(cInd) cInd = [cInd(1)-1:cInd(end)+1]; end
      plot(H(cInd),B(cInd),'Color',ColorsByStimulus{iS},'LineWidth',LineWidth);
      plot([0,1.1*MAX],[0,1.1*MAX],'Color',[0.5,0.5,0.5]);
      text(0.05+iS*0.16,0.9,['S',n2s(iS)],  'Color',ColorsByStimulus{iS},'Units','n','FontSize',7,'FontWeight','bold','Horiz','r');
    end    
  end

  if iC<3  set(gca,'YTick',Stimuli+0.5,'YTickLabel',YTickLabels.(P.Source)); end
  xlabel(XLabels{iC},AxisLabelOpt{:});
  if mod(iC,2) ylabel(YLabels{iC},AxisLabelOpt{:}); end
  box on;
end
set(AH(1:2),'XLim',[0,1.1*MAX],'YLim',[0,length(Stimuli)+1]);
set(AH(3),'XLim',[0,1.1*MAX],'YLim',[0,1.1*MAX]);

% SAVE FIGURES
HF_viewsave('name',[outpath,Name],'view',P.View,'save',P.Save,'format','pdf');
