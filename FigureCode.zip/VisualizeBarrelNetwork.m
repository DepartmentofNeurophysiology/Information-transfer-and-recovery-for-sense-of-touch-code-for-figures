function VisualizeBarrelNetwork(varargin)

  %% PARSE ARGUMENTS
P = parsePairs(varargin);
checkField(P,'PlotStyle','simple');
checkField(P,'MarkerSize',3);
checkField(P,'CellRadius',5);
checkField(P,'Precision',2);
checkField(P,'MultiCol',0);
checkField(P,'Save',1);
checkField(P,'View',0);
checkField(P,'FIG',1);
checkField(P,'Recompute',1);

Dirs = setgetDirs; cDir = Dirs.ITBarrel;
setPlotOpt('neuron','path',cDir,'width',3.5,'height',4); 
Name = 'FIG_ITBarrel_Column'; Sep = HF_getSep;
figure(P.FIG); set(P.FIG,FigOpt{:},'Renderer','OpenGL'); clf;  HF_matchAspectRatio;

[DC,AH] = axesDivide(1,1,[0.2,0.1,0.6,0.88],'c');
hold on;

tmp = load([cDir,'Data',Sep,'Coding_DRate_DTime',Sep,'Coding_DRate_DTime_allparameters.mat'],'l23info','l4info');
P.IL4 = tmp.l4info;
P.IL23 = tmp.l23info;

LayerNames = {'4','23'};

switch lower(P.PlotStyle)
  case '3d'; 
    [XS,YS,ZS] = sphere(P.Precision);
    XS = XS*P.CellRadius;
    YS = YS*P.CellRadius;
    ZS = ZS*P.CellRadius;
end
NLayers = 2;
alim([0,1]);
% PLOT CELLS IN THE COLUMN
for iL =1:NLayers 
  cIL = P.(['IL',LayerNames{iL}]);
  cCellTypes = cIL(:,4);
  UCellTypes{iL} = unique(cCellTypes);
  NTypes(iL) = length(UCellTypes{iL});
  ColorsByType{iL} = cell(NTypes(iL),1);
  cColormap = HF_colormap({[0,0,0.5],[0,0,1],[0.5,0.5,1]},[-1,0,1],NTypes(iL)*10);
  for iT=1:length(UCellTypes{iL})
    cCellType = UCellTypes{iL}(iT);
    if  (iL==1 && cCellType <=2) || (iL==2 && cCellType == 1)
      ColorsByType{iL}{iT} = [1,0,0]; % Excitatory Neurons
    else % Inhibitory Neurons
      if P.MultiCol
        ColorsByType{iL}{iT} = cColormap((iT-1)*10,:);
      else 
        ColorsByType{iL}{iT} = [0,0,1];
      end
    end
    cInd  = find(cCellTypes==cCellType);
    NCells(iT) = length(cInd);
    cPos = cIL(cInd,1:3);
    switch lower(P.PlotStyle)
      case 'simple';
        plot3(AH,cPos(:,1),cPos(:,2),-cPos(:,3),'.','Color',ColorsByType{iL}{iT},'MarkerSize',P.MarkerSize);
      case '3d';
        for iC=1:NCells(iT)
          surf(XS+cPos(iC,1),YS+cPos(iC,2),ZS-cPos(iC,3),'FaceColor',ColorsByType{iL}{iT},...
            'EdgeColor','none','FaceAlpha','flat','AlphaDataMapping','scaled','AlphaData',repmat(0.1,size(ZS)));
        end
    end
  end
end
grid on; box on;
view(40,5);
AxisLabelOpt = {'FontSize',6};
AxisOpt = {'FontSize',5};
HF_matchAspectRatio;
%xlabel('RC [\mum]',AxisLabelOpt{:}); %ylabel('ML [\mum]',AxisLabelOpt{:}); %zlabel('Depth [\mum]',AxisLabelOpt{:});
set(gca,'XTick',[-100,0,100],'YTick',[-100,0,100],'ZTick',[-500,-250,0])
set(gca,AxisOpt{:});
axis([-170,170,-170,170,-650,0]);

% SAVE FIGURES
HF_viewsave('name',[outpath,Name],'view',P.View,'save',P.Save,'format','pdf');