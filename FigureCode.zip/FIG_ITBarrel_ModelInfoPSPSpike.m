function FIG_ITBarrel_ModelInfoPSPSpike(varargin)
  
%% PARSE ARGUMENTS
P = parsePairs(varargin);
checkField(P,'FIG',1); checkField(P,'Save',1);  checkField(P,'View',0);  checkField(P,'Recompute',0);  

% SETUP BASICS
Dirs = setgetDirs; cDir = Dirs.ITBarrel;
setPlotOpt('neuron','path',cDir,'width',4,'height',4.5); 
Sep = HF_getSep;

if P.Recompute  LF_generateData(P.Recompute,inpath,name); end
load([inpath,name]);

% PREPARE FIGURE
figure(P.FIG); clf; set(P.FIG,FigOpt{:}); HF_matchAspectRatio;
DC= axesDivide(1,1,[0.15,0.05,0.82,0.85]); 
Labels = {'D'}; LdPos = [-.14,0.04];
AH = axes('Pos',DC{1}); hold on;
FigLabel(Labels{1},LdPos);
HF_setFigProps;

% START PLOTTING 
Conditions =   {'I_S_PSP','I_S_StVt'};
cWidth = 0.4; YShifts = [1,1,0.8,1,0.8,2.7];

ColumnsToVars = struct('I_S_PSP',1,'I_S_Vm',2,'I_S_Am',3,'I_S_Sl',4,'I_S_Ot',5,'I_S_StVt',6);
ColorsByNeuron = {[1,0,0],[0,0,1]};
CellTypes = {'Excitatory','Inhibitory'};

plot([0,10],[0,0],'Color',[0.5,0.5,0.5],'LineStyle',':');
plot([0,10],[2,2],'Color',[0.5,0.5,0.5],'LineStyle',':');
for iT = 1:length(CellTypes)
  cType = CellTypes{iT};
  for iC = 1:length(Conditions)
    cData = R.(['MI_',cType(1)])(:,ColumnsToVars.(Conditions{iC}));
    BarColor = 'k';
    cPos = (iC-1)*length(CellTypes)+iT;
    boxplot(cData,'Colors',ColorsByNeuron{iT},'Positions',cPos,'widths',cWidth,'symbol','k.');
    h = findobj(gca,'Tag','Box');
    patch(get(h(1),'XData'),get(h(1),'YData'),HF_whiten(ColorsByNeuron{iT},0.5));
    cMean = median(cData);
    plot(cPos + [-cWidth/2,cWidth/2],[cMean,cMean],'-','Color',ColorsByNeuron{iT},'LineWidth',1,'Marker','none')
    switch Conditions{iC}
      case 'H_S'; cLS = 'H(S)';
      case 'I_S_PSP'; cLS = 'I(S;PSP)';
      case 'I_S_Ot'; cLS = 'I(S,Ot)';
      case 'I_S_Am'; cLS = 'I(S,Am)';
      case 'I_S_Sl'; cLS = 'I(S,Sl)';
      case 'I_S_StVt'; cLS = 'I(S;Spike)';
      case 'I_S_St'; cLS = 'I(S;St)';
      case 'I_S_Vt'; cLS = 'I(S;Vt)';
      otherwise error('Label not known');
    end
    XLabels{iC} = cLS;
    fprintf([cLS,' = ',n2s(cMean),' bits (',n2s(100*cMean/2),'%%) \n']);
  end
  text(0.96,1-0.1*(iT),CellTypes{iT},'FontSize',6,'FontWeight','bold','Horiz','r','units','n','Color',ColorsByNeuron{iT});
end
axis([0,5,-0.1,2.8]);
ylabel('MI (bits)');
set(gca,'XTick',[1.5,3.5],'ytick',[0,1,2],'XTickLabel',XLabels);
HF_setFigProps;

% SAVE FIGURES
HF_viewsave('name',[outpath,name],'view',P.View,'save',P.Save,'format','pdf');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function LF_generateData(Recompute,inpath,name)
  
Dirs = setgetDirs; Sep = HF_getSep;

MethodInd = 1;

Conditions = {'DRate_FTime'};
for iC = 1:length(Conditions)
  cCondition = Conditions{iC};
  BasePath = [Dirs.ITBarrel,'Data',Sep,'Coding_',cCondition,Sep];
   
  cFileName = [BasePath,'Coding_',cCondition,'.mat'];
  tmp = load(cFileName,'MI_E_sub','MI_I_sub','MI_E','MI_I');
  R.MI_E = tmp.MI_E_sub;
  R.MI_I = tmp.MI_I_sub;
  R.MI_E(:,6) = squeeze(tmp.MI_E{1}(MethodInd,2,:));
  R.MI_I(:,6) = squeeze(tmp.MI_I{1}(MethodInd,2,:));
end

save([inpath,name],'R')