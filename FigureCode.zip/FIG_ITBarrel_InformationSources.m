function FIG_ITBarrel_InformationSources(varargin)
% TODO
% Meaurement sticks
% Timing figure

%% PARSE ARGUMENTS
P = parsePairs(varargin);
checkField(P,'FIG',1);
checkField(P,'Save',1);  
checkField(P,'View',0);  
checkField(P,'Recompute',0);  

% SETUP BASICS
Dirs = setgetDirs; cDir = Dirs.ITBarrel;
setPlotOpt('neuron','path',cDir,'cols',2,'height',20); 
Sep = HF_getSep;

if P.Recompute  LF_generateData(P.Recompute,inpath,name); end
load([inpath,name]);

% PREPARE FIGURE
figure(P.FIG); clf; set(P.FIG,FigOpt{:}); HF_matchAspectRatio;
Nx = 2; Ny =3;
DC = axesDivide(Nx,[1.2,1,1],[0.18,0.08,0.75,0.85],[0.4],[0.6]); 
% SUBDIVIDE FOR ILLUSTRATION
Nx2 = 3; Ny2 = 3;
for iC=1:2
  DC{1,iC} = axesDivide(Nx2,Ny2,DC{1,iC}+[0,0,0.05,0],[0.2],[0.3]);
end

for i=1:numel(DC)
  if iscell(DC{i})
    for ii=1:numel(DC{i})
       cPos = DC{i}{ii}; if i==1 cPos = cPos-[0.03,0,0,0]; end
      AH{i}{ii} = axes('Pos',cPos); hold on;
    end
    AH{i} = reshape(AH{i},Nx2,Ny2);
  else
    AH{i} = axes('Pos',DC{i}); hold on;
  end
end
AH = reshape(AH,Ny,Nx);
HF_setFigProps;

% PREPARE FOR PLOTTING 
ColorsByStimulus ={[0.1,1,0.85],[0.2,1,0.85],[0.3,1,0.85],[0.5,1,0.85],[0.55,1,0.85]};
for i=1:length(ColorsByStimulus) ColorsByStimulus{i} = hsv2rgb(ColorsByStimulus{i}); end
NeuronColors = {[1,0,0],[0,0,1]};
S = RandStream('mt19937ar','Seed',1);
RandStream.setGlobalStream(S);
LineWidth = 1; 
LineStyles = {'-','--','-.',':'};

% START PLOTTING 
Conds = {'Population','Individual'};
N1 = 3; N2 = 3;
SH  = 0.03;
TimeBins = [0:48];
Z = zeros(1,length(TimeBins)); Z(20) = 1;
PSTH = relaxc(Z,3);
VarPopRate = [0,0.5,1];
IndPopTime = [1,3,4];
VarPopTime = [0,0.5,1];
VarIndRate = [0,1,2];
VarIndTime = [0,1,2];
NStimuli = 4;
NNeuronsShow = 2;
NTrials = 10;
YOff = 0.15;

% PLOT ILLUSTRATION
for iC=1:length(Conds)
  cCond = Conds{iC}; MAX = 0;
  for i1 = 1:N1 % CONDITION 1
    for i2 = 1:N2 % CONDITION 2
      axes(AH{1,iC}{Nx2-i1+1,i2}); 
      for iS = 1:NStimuli % NUMBER OF STIMULI (4)
        for iN = 1:NNeuronsShow % NUMBER OF NEURONS TO SHOW
          for iT = 1:NTrials % NUMBER OF TRIALS TO GENERATE
            switch cCond
              case 'Population'; % DIFFERENT PSTHs
                cPSTH = R.L4_PSTHs{i1,IndPopTime(i2),iS};
                if i1==1 && i2==1 && iS==1 Norm = max(cPSTH); end;
                cPSTH = cPSTH/Norm;
                %cPSTH = PSTH / (1+(iS-1) * VarPopRate(i1));
                %cPSTH = circshift(cPSTH',4*iS*VarPopTime(i2));
                
                % SET SPIKES FOR DISPLAY
                switch iN
                  case 1; cSpikeTimes = 10 + VarPopTime(i2)*iS + VarIndTime(2)*randn/2;
                  case 2; cSpikeTimes = 9 + VarPopTime(i2)*iS + VarIndTime(2)*randn/2;
                end
                if rand>max(cPSTH) cSpikeTimes = []; end% Choose when to change rate
                
              case 'Individual'; % DIFFERENT RELIABILITY
                cPSTH = R.L4_PSTHs{end,end,iS};
                cPSTH = cPSTH/Norm;
                %cPSTH = PSTH / (1+(iS-1) * VarPopRate(3));
                %cPSTH = circshift(cPSTH',4*iS*VarPopTime(3));
                switch iN
                  case 1; cSpikeTimes = {[7,8],[8],[10],[13]};
                  case 2; cSpikeTimes = {[9,11],[10],[11],[13]};
                end
                cSpikeTimes = cSpikeTimes{iS};
                if (i1-1)/2>2*rand cSpikeTimes = []; end% Choose when to change rate
                if (i1-1)/2>2*rand cSpikeTimes(end+1) = 8+iS; end% Choose when to change rate
                cSpikeTimes = cSpikeTimes + randn(size(cSpikeTimes))*VarIndTime(i2)/2;
            end
            % PLOT INDIVIDUAL NEURONS
            for i=1:length(cSpikeTimes)
              cData = 1+((iN-1)*(NTrials*SH+0.2)+1.3*SH*iT+[0,SH]);
              plot(repmat(cSpikeTimes(i),2,1) ,cData,'-',...
                'Color',ColorsByStimulus{iS},'LineWidth',1,'Marker','none');
              MAX = max([MAX,max(cData)]);
            end
            if i1==1 && i2 ==1; text(-2,1.2+(iN-1)*(NTrials*SH+0.2),['C',n2s(iN)],'FontSize',6,'Horiz','r'); end
          end
        end
        % PLOT PSTHs
        cColor = ColorsByStimulus{iS};
        plot(TimeBins,cPSTH,'Color',cColor,'LineWidth',LineWidth,'LineStyle',LineStyles{1});
      end
      
      set(gca,'YTick',[],'XTick',[],'YColor',[1,1,1]);   
    end % END VAR2
  end % END VAR1
  set([AH{1,iC}{:}],'YLim',[0,MAX],'XLim',[0,TimeBins(end)-10]);
  
end % END CONDS

% PLOT ANALYSIS
XLabels = {'Var_T (ms)'}; YLabels = {'Var_C (1)'}; ZLabels = {'MI (bits)'};
CellTypes = {'Excitatory','Inhibitory'};  Decodings = {'Time','Rate'};
MarkerSize = 10; LineWidth = 1.5;
NeuronColors = {[1,0,0],[0,0,1]};

% MAIN PLOTTING
Names = {'Diff. PSTH','Same PSTH'};
set(gcf,'Renderer','OpenGL')

EncodingConds = {'Population','Individual'};

for iC = 1:length(EncodingConds)
  cEncodingCond = EncodingConds{iC};
  cR = R.(cEncodingCond);
  cRateCondition = 'DRate';
  for iD = 1:length(cR.Decodes)
    axes(AH{iD+1,iC}); hold on;

    cDecode = cR.Decodes{iD};
    switch cEncodingCond
      case 'Individual'; 
        cUTimes = cR.(cRateCondition).UTimes;
        cUCounts = cR.(cRateCondition).UCounts * 100;
      case 'Population';
        cUTimes = cR.UTimes;
        cUCounts = cR.UCounts;
    end 
    [T,C] = meshgrid(cUTimes,cUCounts);
    UTimesFine = [cUTimes(1):0.1:cUTimes(end)];
    UCountsFine = [cUCounts(1):0.1:cUCounts(end)];
    [TFine,CFine] = meshgrid(UTimesFine,UCountsFine);

    for iT=1:length(CellTypes)        
      switch cEncodingCond
        case 'Individual';
          cData = squeeze(cR.(cRateCondition).(cDecode).MIVarTC(:,:,iT));
          cData = flipud(cData);
          cDataFine = interp2(T,C,cData,TFine,CFine);
        case 'Population';
          cData = squeeze(cR.(cDecode).MIVarTC(:,:,iT));
          cDataFine = interp2(T,C,cData,TFine,CFine);
          cDataFine(1:9,1:9) = NaN;
          cData(1,1) = NaN;
        otherwise
      end
      H = surf(TFine,CFine,cDataFine,'FaceColor',NeuronColors{iT},'EdgeColor','none');
      set(H,'facealpha',0.5);
      H = surf(T,C,cData,'FaceColor','none','edgecolor',[0,0,0]);
      set(H,'edgealpha',0.5,'facealpha',1);
      view(35,10);
      %title(['Decoding: ',cR.Decodes{iD} ],TitleOpt{:},'Interpreter','none','FontSize',10);
      %xlabel(XLabels{1});
      %ylabel(YLabels{1});
      %if iC==1 zlabel(ZLabels{1}); end
      zlim([0,2]);
      switch cEncodingCond
        case 'Population'; 
          xlim([-0.5,3.5]); ylim([0.5,4.5]); 
          set(gca,'XTick',[0:3],'YTick',[0:4])
        case 'Individual'; 
          xlim([-0.5,5.5]); ylim(100*[-0.2,1.2]);
          set(gca,'XTick',[0:5],'YTick',[0:50:100])
      end
      box off; grid on;
    end
  end
end

HF_setFigProps;

% SAVE FIGURES
HF_viewsave('name',name,'path',outpath,'view',P.View,'save',P.Save,'format','pdf','res',600);

function LF_generateData(Recompute,inpath,name)
  
  Dirs = setgetDirs; Sep = HF_getSep;
  
  % POPULATION VS INDIVIDUAL
  MethodInd = 1;
  RateInd  = 6;
  cBinSizeInd = 3;
  Vars = {'MI_E','MI_I'}; VarMatch = struct('MI_E','Excitatory','MI_I','Inhibitory');
  Rates = {'D','F'};
  NCellsSel = 100;
  
  EncodingConds = {'Population','Individual'};
  for iCC = 1:length(EncodingConds)
    switch EncodingConds{iCC}
      case 'Population'
        BasePath = [Dirs.ITBarrel,'Data',Sep,'Coding_pPSTH_Rate_Time',Sep];
        Files = dir([BasePath,'Coding_*.mat']);
        for iC = 1:length(Files)
          cName = Files(iC).name;
          Pos = find(cName=='_');
          R.Conditions{iC} = cName(Pos(1)+1:Pos(4)-1);
          cCondition = R.Conditions{iC};
          cCount = str2num(cName(Pos(2)+2:Pos(3)-1));
          cTime = str2num(cName(Pos(3)+2:Pos(4)-1));
          
          % LOAD DATA
          cFileName = [BasePath,cName];
          tmp = load(cFileName,Vars{:},'Cell_N');
          for iV = 1:length(Vars)
            cVar = Vars{iV};
            cField = VarMatch.(cVar);
            if ~isempty(tmp.(cVar))
              tmp.Rate.(cField) = LF_transformData(tmp.(cVar),RateInd);
              tmp.Time.(cField) = LF_transformData(tmp.(cVar),cBinSizeInd);
              tmp.Rate.Cells  = tmp.Cell_N;
              tmp.Time.Cells = tmp.Cell_N;
              tmp.VarCount = cCount;
              tmp.VarTime = cTime;
            end
          end
          R.(cCondition) = tmp;
          Counts(iC) = cCount;
          Times(iC) = cTime;
        end
        UCounts = unique(Counts);
        UTimes = unique(Times);
        R.UCounts = UCounts;
        R.UTimes = UTimes;
        CellTypes = {'Excitatory','Inhibitory'};
        R.Decodes = {'Time','Rate'};
        
        
        for iC = 1:length(Counts) % Loop over Conditions again
          cCondition = R.Conditions{iC};
          IndC = find(Counts(iC) == UCounts);
          IndT = find(Times(iC) == UTimes);
          for iD = 1:length(R.Decodes)
            cDecode = R.Decodes{iD};
            cCells = R.(cCondition).(cDecode).Cells;
            NCellsInd = find(cCells == NCellsSel);
            for iT = 1:length(CellTypes)
              R.(cDecode).MIVarTC(IndC,IndT,iT) = ...
                mean(R.(cCondition).(cDecode).(CellTypes{iT})(NCellsInd,:));
            end
          end
        end
        
      case 'Individual'
        for iR = 1:2 % DIFFERENT RATE CONDITIONS
          clear Counts Times;
          cRate = Rates{iR};
          R.RateConditions{iR} = [cRate,'Rate'];
          cRateCondition = R.RateConditions{iR};
          BasePath = [Dirs.ITBarrel,'Data',Sep,'Coding_',cRate,'Rate_Vcount_Vtime',Sep];
          Files = dir([BasePath,'Coding_*.mat']);
          for iC = 1:length(Files)
            cName = Files(iC).name;
            Pos = find(cName=='_');
            R.(cRateCondition).Conditions{iC} = cName(Pos(1)+1:Pos(4)-1);
            cCondition = R.(R.RateConditions{iR}).Conditions{iC};
            cCount = str2num(cName(Pos(2)+3:Pos(3)-1))/10;
            cTime = str2num(cName(Pos(3)+3:Pos(4)-1));
            % if ~cTime cTime = 7; end % CH special
            
            % LOAD DATA
            cFileName = [BasePath,cName];
            tmp = load(cFileName,Vars{:},'Cell_N');
            for iV = 1:length(Vars)
              cVar = Vars{iV};
              cField = VarMatch.(cVar);
              if ~isempty(tmp.(cVar))
                tmp.Rate.(cField) = LF_transformData(tmp.(cVar),RateInd);
                tmp.Time.(cField) = LF_transformData(tmp.(cVar),cBinSizeInd);
                tmp.Rate.Cells  = tmp.Cell_N;
                tmp.Time.Cells = tmp.Cell_N;
                tmp.VarCount = cCount;
                tmp.VarTime = cTime;
              end
            end
            R.([cRate,'Rate']).(cCondition) = tmp;
            Counts(iC) = cCount;
            Times(iC) = cTime;
          end
          UCounts = unique(Counts);
          UTimes = unique(Times);
          R.([cRate,'Rate']).UCounts = UCounts;
          R.([cRate,'Rate']).UTimes = UTimes;
          R.Decodes = {'Time','Rate'};
          CellTypes = {'Excitatory','Inhibitory'};
          
          for iC = 1:length(Counts) % Loop over Conditions again
            cCondition = R.(cRateCondition).Conditions{iC};
            IndC = find(Counts(iC) == UCounts);
            IndT = find(Times(iC) == UTimes);
            for iD = 1:length(R.Decodes)
              cDecode = R.Decodes{iD};
              cCells = R.(cRateCondition).(cCondition).(cDecode).Cells;
              NCellsInd = find(cCells == NCellsSel);
              for iT = 1:length(CellTypes)
                R.(cRateCondition).(cDecode).MIVarTC(IndC,IndT,iT) = ...
                  mean(R.(cRateCondition).(cCondition).(cDecode).(CellTypes{iT})(NCellsInd,:));
              end
            end
          end
        end
    end
    RR.(EncodingConds{iCC}) = R;
  end
  R = RR;
  
  % LOAD PSTHs & SINGLE CELL SPIKETIMES for DISPLAY
  cPath = [Dirs.ITBarrel,'Data',Sep,'L4_PSTH',Sep,'pPSTH',Sep];
  Files = dir([cPath,'*.mat']);
  for iF=1:length(Files)
    cRateInd = str2num(Files(iF).name(12));
    cTimeInd = str2num(Files(iF).name(end-4))+1;
    tmp = load([cPath,Files(iF).name]);
    for iStim=1:4
      R.L4_PSTHs{cRateInd,cTimeInd,iStim} = tmp.(['psth_',n2s(iStim)]);
      tmp2 = load([cPath,'Rate_',n2s(cRateInd),'_Time_',n2s(cTimeInd-1),'_vc08_vt3',Sep,'l4spt_S',n2s(iStim),'_vc08_vt3.mat']);
      R.L4_Responses{cRateInd,cTimeInd,iStim} = tmp2.spt_all(1:20);
    end
  end
  
  
  save([inpath,name],'R')
  
function M = LF_transformData(C,SelInd)
 M = cell2mat(C);
 M = squeeze(M(1,:,:));
 M = reshape(M,[size(C{1},2),length(C),size(C{1},3)]);
 M = squeeze(M(SelInd,:,:));