function FIG_ITBarrel_ResponsePSTH(varargin)
% TODO
% Meaurement sticks
% Timing figure
  
%% PARSE ARGUMENTS
P = parsePairs(varargin);
checkField(P,'FIG',1);
checkField(P,'Save',1);  
checkField(P,'View',0);  
checkField(P,'Recompute',0);  

% SETUP BASICS
Dirs = setgetDirs; cDir = Dirs.ITBarrel;
setPlotOpt('neuron','path',cDir,'width',5,'height',5); 
Sep = HF_getSep;

if P.Recompute  LF_generateData(P.Recompute,inpath,name); end
load([inpath,name]);

% PREPARE FIGURE
figure(P.FIG); clf; set(P.FIG,FigOpt{:}); HF_matchAspectRatio;
DC= axesDivide(1,[1,1.2],[0.25,0.2,0.7,0.75],[],[0.02]); 
Labels = {'B'}; LdPos = [-.14,.0];
for i=numel(DC):-1:1
    AH(i) = axes('Pos',DC{i}); hold on; 
    if i == 1 FigLabel(Labels{i},LdPos); end
end
HF_setFigProps;

% START PLOTTING 
PlotTypes = {'PSTH','Raster'};
XLabels = {'Time (ms)'};
YLabels = {'FR (Hz)','Depth (\mum)'};
CellTypes = {'L4','Inhibitory','Excitatory'};
MarkerSize = 4; LineWidth = 1;
ColorsByNeuron = struct('L4',[0.5,0.5,0.5],'Excitatory',[1,0,0],'Inhibitory',[0,0,1]);

iS = 1; iT = 1;
for iP=1:length(PlotTypes)
  axes(AH(iP)); hold on;
  switch PlotTypes{iP}
    case 'PSTH';
      for iT = 1:length(CellTypes)
        cType = CellTypes{iT}; cColor= ColorsByNeuron.(cType);
        AddString = []; if iT>1 AddString = 'L2/3 '; end
        switch iT
          case 1; cFaceColor = HF_whiten(cColor,0.5);
          case 2; cFaceColor = HF_whiten(cColor,0.5);
          case 3; cFaceColor = (HF_whiten(cColor,0.5) + HF_whiten([0,0,1],0.75))/2;
        end
        area(R.TimeBins,R.(cType).PSTHs{iS},'FaceColor',cFaceColor,'LineWidth',LineWidth);
        %plotarea(R.TimeBins,R.(cType).PSTHs{iS},'Color',cColor,'LineWidth',LineWidth);
        text(0.5,1-iT*0.15,[AddString,cType],  'Color',cColor,'Units','n','FontSize',7,'FontWeight','bold','Horiz','l');
      end
      axis([0,R.TimeBins(end)+1,0,150]);
      set(gca,'xtick',[],'ytick',[0,50,100]);
      
    case 'Raster';
      for iT = 2:length(CellTypes)
        cType = CellTypes{iT};
        cSpikeTimes = R.(cType).SpiketimesByTrial;
        cDepths = R.(cType).DepthsByNeuron;
        cDepths = repmat(cDepths,1,size(cSpikeTimes,2));
        cInd = cSpikeTimes>0;
        plot(cSpikeTimes(cInd),cDepths(cInd),'.',...
          'Color',ColorsByNeuron.(cType),'LineWidth',0.5,'MarkerSize',MarkerSize);
      end
      axis([0,R.TimeBins(end)+1,0,450]);
      set(gca,'XTick',[0,50,100],'ytick',[100:100:400],'ydir','reverse');
  end
  if iP==2 xlabel(XLabels{1}); end
  ylabel(YLabels{iP});
  if iP==2 set(gca,'XTick',[0,25,50]); end
end
HF_setFigProps;
set(gcf,'Renderer','painters')
% SAVE FIGURES
HF_viewsave('name',[outpath,name],'view',P.View,'save',P.Save,'format','pdf');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function LF_generateData(Recompute,inpath,name)
  
Dirs = setgetDirs; Sep = HF_getSep;

Conditions = {'DRate_DTime'};
for iC = 1:length(Conditions)
  cCondition = Conditions{iC};
  BasePath = [Dirs.ITBarrel,'Data',Sep,'Coding_',cCondition,Sep];
   
  % LOAD OTHER INFO
  cFileName = [BasePath,'Coding_',cCondition,'_allparameters.mat'];
  tmp = load(cFileName,'l23info','lp','fpE','l23spt_A_con');
  R.IL23 = tmp.l23info;
  R.ITrials = tmp.fpE;
  R.AL23 = tmp.l23spt_A_con;
  IndEx = R.IL23(:,4)==1;
  IndInh = R.IL23(:,4)>1;
  R.Excitatory.DepthsByNeuron = R.IL23(IndEx,3);
  R.Inhibitory.DepthsByNeuron = R.IL23(IndInh,3);
  Stimuli = R.ITrials(:,2); UStimuli = unique(Stimuli); R.NStimuli = length(UStimuli);
  
  for iS = 1:R.NStimuli
    cStimulus = UStimuli(iS);
    
    % LOAD L2/3 PSTHs
    StimInd = [cStimulus == Stimuli];
    [R.Excitatory.PSTHs{iS},R.TimeBins,R.NNeurons,R.NTrials] ...
      = LF_ST2PSTH(R.AL23,StimInd,IndEx);
    R.Excitatory.SpiketimesByTrial = R.AL23{100}(IndEx,:)-40;
    R.Inhibitory.PSTHs{iS} = LF_ST2PSTH(R.AL23,StimInd,IndInh);
    R.Inhibitory.SpiketimesByTrial = R.AL23{100}(IndInh,:)-40;
  end
  
  % LOAD L4 PSTHs
  BasePath = [Dirs.ITBarrel,'Data',Sep,'L4_PSTH',Sep];
  Names = {'PW','2PW','1PW','SW'};
  R.NStimuli = length(Names);
  for iP = 1:length(Names)
    cFileName = [BasePath,'l4spt_',Names{iP},'_1.mat'];
    tmp = load(cFileName);
    R.L4.PSTHs{iP} = LF_ST2PSTH(tmp.spt_all,[]);
    R.L4.SpikeTimesByTrial{iC}{iP} = tmp.spt_all;
  end
  
end

save([inpath,name],'R')
  
function [PSTH,TimeBins,NNeurons,NTrials] = LF_ST2PSTH(ST,StimInd,CellInd)
if exist('TrialInd','var') && ~isempty(TrialInd) ST = ST(StimInd); end; 
M = cell2mat(ST);
if exist('CellInd','var') && ~isempty(CellInd) M = M(CellInd,:); else CellInd = ones(size(ST{1},1),1); end;
NTrials = length(ST);
NNeurons = sum(CellInd);
M = M(:); M=M(M~=0)-40;
TimeBins = [1:50]; % in ms
PSTH = hist(M,TimeBins)/(NTrials*NNeurons)*1000;