function FIG_ITBarrel_MutualInformation(varargin)
%% PARSE ARGUMENTS
P = parsePairs(varargin);
checkField(P,'View',0);  
checkField(P,'Save',1);  
checkField(P,'FIG',1);

% SETUP BASICS
Dirs = setgetDirs; cDir = Dirs.ITBarrel;
setPlotOpt('neuron','path',cDir,'cols',1.5,'height',8.5); 
Name = ['FIG_ITBarrel_MutualInformation']; Sep = HF_getSep;

% DEFINE DATA (from file data_v4.xls)
R.H_S = [1.9126	1.9953	1.7108	1.4952	1.9303	1.9956	1.6224	1.9968	1.9329	1.9779	1.9445];
R.H_Vt = [2.5048	2.7389	2.4195	2.1184	2.7564	2.3912	2.7848	2.2602	2.2825	2.574	2.5612]; 
R.H_St = [2.7462	2.7046	2.4352	1.9812	2.6577	2.6711	2.618	1.9184	2.2481	2.4305	2.4267];
R.H_PSP = [5.1445  6.4278  6.6785  6.091  6.9935  6.3122  6.3143  6.1608  6.9876  6.9231  7.0749];
R.I_S_PSPStVt = [2.8845	3.2167	2.5884	2.1166	3.6218	2.3415	1.8564	2.9008	2.802	3.1412	2.8758];
R.I_S_PSP = [2.0041	2.0603	1.7189	1.3741	2.1025	1.3814	1.3545	1.9471	1.843	2.2084	1.9094];
R.I_S_StVt = [0.6229	0.6751	0.2209	0.1417	0.6785	0.5863	0.2194	0.3261	0.4909	0.47	0.3462];
R.I_PSP_St = [1.4051	1.5287	1.5391	0.8459	1.6697	1.442	2.0029	1.6288	0.9394	1.0863	1.3456];
R.I_S_St = [0.4039	0.5654	0.1643	0.1258	0.4557	0.3627	0.1361	0.2879	0.3259	0.3019	0.3146];
R.I_PSPS_Vt = [1.001	1.5639	1.8769	0.676	2.2469	0.9279	2.1351	1.3986	1.2571	1.2696	1.2728];
R.I_PSP_Vt = [0.6415	1.1069	1.3629	0.5486	1.5872	0.7822	1.625	0.9554	0.9929	0.9562	1.0172];
R.I_S_Vt = [0.1559	0.061	0.1615	0.0594	0.2448	0.1534	0.06	0.2462	0.125	0.0374	0.055];
R.I_PSPS_St = [1.9652	2.2217	1.9994	1.0134	2.351	1.8629	2.5279	2.2227	1.2881	1.5419	1.6238];
R.I_S_PSP_Joint = [2.004  1.20603  1.7189  1.3741  2.1025  1.3814  1.3545  1.9471  1.843  2.2084  1.9094];
R.I_S_PSP_Sum = [1.8214	1.9362	1.7681	1.5517	2.0716	1.362	0.8368	1.7188	1.7169	2.2502	1.9294];
R.I_S_PSP_Syn = [0.1827	0.1242	-0.0492	-0.1775	0.031	0.0194	0.5177	0.2282	0.1261	-0.0418	-0.02];
R.I_PSP_St_Joint = [1.4051	1.5287	1.5391	0.8459	1.6697	1.442	2.0029	1.6288	0.9394	1.0863	1.3456];
R.I_PSP_St_Sum = [0.9915	1.0924	1.3776	0.709	1.1726	0.9929	1.5803	1.3783	0.6044	0.8079	0.8067];
R.I_PSP_St_Syn = [0.4136	0.4362	0.1614	0.1369	0.4971	0.4491	0.4226	0.2505	0.335	0.2784	0.5389];
R.I_PSP_Vt_Joint = [0.6415	1.1069	1.3629	0.5486	1.5872	0.7822	1.625	0.9554	0.9929	0.9562	1.0172];
R.I_PSP_Vt_Sum = [0.6232	1.0619	1.2974	0.4644	1.3922	0.6013	1.5146	0.7904	0.9857	0.8814	0.8925];
R.I_PSP_Vt_Syn = [0.0183	0.045	0.0655	0.0842	0.195	0.1809	0.1104	0.1651	0.0072	0.0747	0.1247];
R.I_S_Am = [0.1665	0.0523	0.2981	0.1653	0.0831	0.1272	0.1742	0.0759	0.0649	0.1316	0.0776];
R.I_S_Sl = [0.1147	-0.0115	0.1762	0.3298	0.1929	0.2337	0.079	0.2388	0.1402	0.1689	0.1507];
R.I_S_Ot = [1.7388	1.855	1.3793	1.3916	1.7916	1.2692	0.837	1.5526	1.6133	1.8479	1.7775];

% PREPARE FIGURE
figure(P.FIG); clf; set(P.FIG,FigOpt{:}); HF_matchAspectRatio;
Nx = 3; Ny = 2;
AxisOpt = {'FontSize',6};
LabelOpt = {'FontSize',11,'FontWeight','Bold'};
DC= axesDivide(Nx,Ny,[0.06,0.12,0.9,0.82],[0.4],[0.8]); 
Labels = {'A','B','C','D','E','F'}; LdPos = [-.06,.035];
for iX=1:size(DC,2)
  for iY = 1:size(DC,1)
    AH(iX,iY) = axes('Pos',DC{iY,iX}); 
    hold on; FigLabel(Labels{(iY-1)*Nx+iX},LdPos);
  end
end
HF_setFigProps;

% START PLOTTING 
Conditions = {...
  {'H_S','I_S_PSP','I_S_StVt'},...
  {'I_S_Ot','I_S_Sl','I_S_Am'},... 
  {'I_S_PSP_Joint','I_S_PSP_Sum','I_S_PSP_Syn'},...
  {'I_S_St','I_S_Vt','I_S_StVt'},...
  {'H_PSP','I_PSP_St','I_PSP_Vt'}...
  {'I_PSP_St_Joint','I_PSP_St_Sum','I_PSP_St_Syn'},... 
  };
BarColor = 'k'; MeanColor = 'r'; MAX = 0;
Marker = '.'; MarkerSize = 8; LineWidth = 2;
YLabels = 'Mutual Information (bits)';
Flag = 0;
cWidth = 0.4; YShifts = [1,0.8,0.5,1,2,1.7];
for iC = 1:length(Conditions)
  axes(AH(iC));    
  %fprintf([Conditions{iC}{1},': \n']);
  XLabels = {}; FLabel = '';
  NBars = length(Conditions{iC});
  plot([0,10],[0,0],'Color',[0.5,0.5,0.5],'LineStyle',':');
  for iCC =1:length(Conditions{iC})
    % PLOT DATA
    cField = Conditions{iC}{iCC};
    if isfield(R,cField)
      cData = R.(cField);
      if iC<5 MAX = max([MAX,cData]); end
      boxplot(cData,'Colors',BarColor,'Positions',iCC,'widths',cWidth,'symbol','r.');
      plot([iCC-cWidth/2,iCC+cWidth/2],[median(cData),median(cData)],'-','Color','r','LineWidth',1,'Marker','none')
    end
    switch Conditions{iC}{iCC}
      case 'H_S'; cLS = 'H(S)';
      case 'H_Vt'; cLS = 'H(Vt)';
      case 'H_St'; cLS = 'H(St)';
      case 'I_PSP_StVt'; cLS = 'I(PSP;Spike)';
      case 'I_S_PSP'; cLS = 'I(S;PSP)';
      case 'I_S_Ot'; cLS = 'I(S,Ot)';
      case 'I_S_Am'; cLS = 'I(S,Am)';
      case 'I_S_Sl'; cLS = 'I(S,Sl)';
      case 'I_S_StVt'; cLS = 'I(S;Spike)';
      case 'I_S_St'; cLS = 'I(S;St)';
      case 'I_S_Vt'; cLS = 'I(S;Vt)';
      case 'I_PSP_St'; cLS = 'I(PSP;St)';
      case 'I_PSPS_Vt'; cLS = 'I({PSP;S};Vt)';
      case 'I_PSP_Vt'; cLS = 'I(PSP;Vt)';
      case 'I_PSPS_St'; cLS = 'I({PSP;S;St)';
      case 'I_S_PSP_Joint'; cLS = 'Joint'; FLabel = 'I(S;PSP)';
      case 'I_S_PSP_Sum'; cLS = 'Sum';
      case 'I_S_PSP_Syn'; cLS = 'Synergy';
      case 'I_PSP_St_Joint'; cLS = 'Joint'; FLabel = 'I(PSP;St)';
      case 'I_PSP_St_Sum'; cLS = 'Sum';
      case 'I_PSP_St_Syn'; cLS = 'Synergy';
      case 'I_PSP_Vt_Joint'; cLS = 'Joint'; FLabel = 'I(PSP;Vt)';
      case 'I_PSP_Vt_Sum'; cLS = 'Sum';
      case 'I_PSP_Vt_Syn'; cLS = 'Synergy';
      case 'H_PSP'; cLS = 'H(PSP)';
      otherwise error('Label not known');
    end
    XLabels{iCC} = cLS;
    cM = median(cData);  
    if strcmp(XLabels{iCC},'H(PSP)') Flag = 1; cBitMax = cM; end; 
    if ~Flag cBitMax = 2; end;
    [Sig,PP] = ttest(cData);
    fprintf([Labels{iC},'\t ',XLabels{iCC},'\t=',n2s(cM,2),'bits (',n2s(100*cM/cBitMax,2), '%%, p=',n2s(PP,2),') \n']);
    plot([0,10],[cBitMax,cBitMax],'Color',[0.5,0.5,0.5],'LineStyle',':'); 
  end
  if ~isempty(FLabel) text(0.95,0.9,FLabel,'Units','n','Horiz','right',TextOpt{:}); end
  ylabel(YLabels);
  box on;
  set(AH(iC),'XLim',[0.7,NBars + 0.3],'XTick',[1:NBars],'XTickLabel',XLabels);
  rotateticklabel(AH(iC),-45,0.2,YShifts(iC)); set(gca,'XTickLabel',{''});
end
set(AH(1:4),'YLim',[-0.5,1.2*MAX],'YTick',[0,1,2,3]);
set(AH([5,6]),'YLim',[-0.5,8.5],'YTick',[0:2:8]);
% SAVE FIGURES
HF_viewsave('name',[outpath,Name],'view',P.View,'save',P.Save,'format','pdf');