function FIG_ITBarrel_Reconstruction(varargin)
% TODO
% Meaurement sticks
% Timing figure
  
%% PARSE ARGUMENTS
P = parsePairs(varargin);
checkField(P,'FIG',1);
checkField(P,'Save',1);  
checkField(P,'View',0);  
checkField(P,'Recompute',0);  

% SETUP BASICS
Dirs = setgetDirs; cDir = Dirs.ITBarrel;
setPlotOpt('neuron','path',cDir,'cols',1,'height',10); 
Sep = HF_getSep;

if P.Recompute  LF_generateData(P.Recompute,inpath,name); end
load([inpath,name]);

% PREPARE FIGURE
figure(P.FIG); clf; set(P.FIG,FigOpt{:}); HF_matchAspectRatio;
Nx = 2; Ny = 4;
DC = axesDivide([0.6,1],Ny,[0.14,0.08,0.84,0.9],[0.4],[1.2,0.6,0.6]); 
CenterShift = 0.15;
DC{1,1} = DC{1,1} + [0,0,CenterShift,0];
DC{1,2} = DC{1,2} + 1*[CenterShift,0,-CenterShift,0];
Labels = {'B','C','D','E','F','G'}; LdPos = [-.12,.0];
PlotInd = [1,5,2,3,4];
for i=1:numel(DC)
  AH(i) = axes('Pos',DC{i}); hold on;
  Pos = find(i == PlotInd);
  if ~isempty(Pos) 
    Shift = 0;
    %     if i==1 Shift = [0.07,0]; end
    if i==6 Shift = [0.07,0]; end
    FigLabel(Labels{Pos},LdPos+Shift,'Horiz','Center'); 
  end
end
AH = reshape(AH,Ny,Nx)';
HF_setFigProps;

% START PLOTTING 
PlotTypes = {'PSTH','MI'};
XLabels = {'Time (ms)','Neurons (#)'};
YLabels = {'FR (Hz)','MI (bits)'};
CellTypes = {'Excitatory','Inhibitory'};
Decodings = {'Time','Rate'};
LineStyles = {''};
MarkerSize = 1; LineWidth = 1.5;
NNeuronsShow = 3;
NTrials = 6;
ColorsByStimulus ={[0.1,1,0.85],[0.2,1,0.85],[0.3,1,0.85],[0.5,1,0.85],[0.55,1,0.85]};
for i=1:length(ColorsByStimulus) ColorsByStimulus{i} = hsv2rgb(ColorsByStimulus{i}); end
LineStyles = {'-','--','-.',':'};
NeuronColors = {[1,0,0],[0,0,1]};

% PLOT THE REAL & CONTROL DATA 
Conditions = {'Real','FRate_DTime'};
for iC=1:length(Conditions)
  axes(AH(iC,1));
  LF_plotGroupMIs(R,Conditions{iC},Decodings,CellTypes,MarkerSize,NeuronColors,LineWidth,iC==2)
  xlabel(XLabels{2});
  if iC == 1 h = ylabel(YLabels{2}); end;
end

% SET SPIKES FOR DISPLAY
S = RandStream('mt19937ar','Seed',1);
RandStream.setGlobalStream(S);
for iC=1:3
  for iS = 1:R.NStimuli
    if iC<3 cRate = 1/iS; else cRate = 1; end
    for iN = 1:NNeuronsShow
      cNSpikes = round(2*(1-(1-cRate)*rand));      
      SpikeTimes = 8+rand*ones(1,cNSpikes) + 4*(1-cRate);
      TimingJitter = randn([1,cNSpikes])/2;
      for iT = 1:NTrials
        switch iC
          case 1;
            TimingJitter = randn([1,cNSpikes])/cRate + 1/cRate;
        end
        SpikeTimesByTrial{iC}{iS}{iT}{iN} = SpikeTimes + TimingJitter;
      end
    end
  end
end

% MAIN PLOTTING
Conditions = {'DRate_DTime','DRate_FTime','FRate_FTime'};
Names = {'Rate + Poisson','Rate + Trial Reliab.','No Rate + Trial Reliab.'};
for iC = 1:length(Conditions)
  cCondition = Conditions{iC};
  for iP=1:length(PlotTypes)
    axes(AH(iP,iC+1));
    switch PlotTypes{iP}
      case 'PSTH';
        for iS=1:R.NStimuli
          cColor = ColorsByStimulus{iS};
          if iC == 1 text(1,1.1-iS*0.15,['S',n2s(iS)],  'Color',cColor,'Units','n','FontSize',7,'FontWeight','bold','Horiz','r'); end
          if iC == 3 iSS = 1; iL = iS; else iSS = iS; iL = 1; end
          plot(R.TimeBins,R.L4_PSTHs{iSS},'Color',cColor,'LineWidth',LineWidth,'LineStyle',LineStyles{iL});
        end
        SH  = 3; YOff = 115;
        for iN = 1:NNeuronsShow
          for iS = R.NStimuli:-1:1
            for iT = 1:NTrials
              cTime = SpikeTimesByTrial{iC}{iS}{iT}{iN};
              for i=1:length(cTime)
                plot(repmat(cTime(i),2,1) ,YOff+(iN-1)*(NTrials*SH+15)+1.3*SH*iT+[0,SH],'-','Color',ColorsByStimulus{iS},'LineWidth',0.5,'Marker','none');
              end
              text(-2,YOff+15+(iN-1)*36,['Cell ',n2s(iN)],'FontSize',6,'Horiz','r');
            end
          end
        end
        text(0.5,1.1,Names{iC},'Horiz','center','Units','n','FontName','Arial','FontWeight','Bold','FontSize',6);
        axis([0,R.TimeBins(end)+1,0,2.1*max(R.L4_PSTHs{1})]);
        set(gca,'YTick',[0,50,100]);
        
      case 'MI';
        LF_plotGroupMIs(R,cCondition,Decodings,CellTypes,MarkerSize,NeuronColors,LineWidth,0);
    end
    if iC == length(Conditions) xlabel(XLabels{iP}); end
    h = ylabel(YLabels{iP}); if iP == 1 set(h,'Position',[-15,50,0]); end
    if iP==1 set(gca,'XTick',[0,25,50]); end
  end
end

HF_setFigProps;

% SAVE FIGURES
HF_viewsave('name',name,'path',outpath,'view',P.View,'save',P.Save,'format','pdf','res',400);


function LF_plotGroupMIs(R,cCondition,Decodings,CellTypes,MarkerSize,NeuronColors,LineWidth,Labels)

for iD = 1:length(Decodings)
  cDecoding = Decodings{iD};
  CompletePos = {};   CompleteVal = {};
  for iT = 1:length(CellTypes)
    cType = CellTypes{iT};
    if isfield(R.(cCondition).(cDecoding),cType)
      cData = R.(cCondition).(cDecoding).(cType);
      cMean = nanmean(cData,2);
      Neurons = R.(cCondition).(cDecoding).Cells;
      NSamples = size(cData,2);
      cSD = std(cData,[],2);
      cError = cSD/sqrt(NSamples);
      cColor = HF_whiten(NeuronColors{iT},(iD-1)/1.5);
      %errorbar(Neurons,cMean,cSD,...    
        plot(Neurons,cMean,...
        'Marker','.','MarkerSize',MarkerSize,'Color',cColor,'LineWidth',LineWidth);
      if Labels
        text(1 - (iT-1)*0.45,0.8-iD*0.25,[Decodings{iD},'_{',cType(1:2),'}'],...
          'Color',cColor,'Units','n','FontSize',7,'FontWeight','bold','Horiz','r');
      end
      fprintf([cCondition,' = ',n2s(cMean(end)),' bits (',n2s(100*cMean(end)/2),'%%) \n']);
    end
    CompletePos{iT} = find(cMean>1.8,1,'first');
    if ~isempty(CompletePos{iT}) CompleteVal{iT} = cMean(CompletePos{iT}); end
  end  
end
  % PLOT GREY LINE
  [Pos,cInd] = min(cell2mat(CompletePos'));
  CompleteVal = cell2mat(CompleteVal);
  if ~isempty(Pos)
    plot([Neurons(Pos),Neurons(Pos)],[0,CompleteVal(cInd)],'Color',[0.7,0.7,0.7],'Linewidth',2);
  end

plot(Neurons([1,end]),[2,2],'-','Color',[0.6,0.6,0.6]);
axis([0,Neurons(end)+1,0,2.2]);
set(gca,'XTick',[0,50,100],'XLim',[0,105],'YTick',[0,1,2]);

function LF_generateData(Recompute,inpath,name)
  
Dirs = setgetDirs; Sep = HF_getSep;

try load([inpath,name]); end

MethodInd = 1;
RateInd  = 6;
cBinSizeInd = 3;
R.Conditions = {'DRate_DTime','DRate_FTime','FRate_FTime','FRate_DTime','DRate_logn_corr_cv05','Real'};
Vars = {'MI_E','MI_I'}; VarMatch = struct('MI_E','Excitatory','MI_I','Inhibitory');
for iC = 1:length(R.Conditions)
  cCondition = R.Conditions{iC};
  BasePath = [Dirs.ITBarrel,'Data',Sep,'Coding_',cCondition,Sep];
  % LOAD DATA
  cFileName = [BasePath,'Coding_',cCondition,'_1-100_classify_1stspike_SVM.mat'];
  tmp = load(cFileName,Vars{:},'Cell_N');
  for iV = 1:length(Vars)
    cVar = Vars{iV};
    cField = VarMatch.(cVar);
    if ~isempty(tmp.(cVar))
      R.(cCondition).Rate.(cField) = LF_transformData(tmp.(cVar),RateInd);
      R.(cCondition).Time.(cField) = LF_transformData(tmp.(cVar),cBinSizeInd);
      R.(cCondition).Rate.Cells  = tmp.Cell_N;   
      R.(cCondition).Time.Cells = tmp.Cell_N;
    end
  end
  
  if iC == 1
    % LOAD OTHER INFO
    cFileName = [BasePath,'Coding_',R.Conditions{iC},'_allparameters.mat'];
    tmp = load(cFileName,'l23info','lp');
    R.L23Info = tmp.l23info;
  end
end


% LOAD CLASSIFICATION PERFORMANCE FOR THE REAL DATA FOR DIFFERENT METHODS
Methods = {'cla_diagLin','cla_linear','cla_quadratic','SVM'}; 
for iM = 1:length(Methods)
  cMethod = Methods{iM};
  cFile = ['MI_invitro_montecarlo_1stspike_100_classify_1stspike_',cMethod,'_Cmat.mat'];
  cFileName = [BasePath,cFile];
  tmp = load(cFileName,'Cmat');
  CM.(cMethod) = tmp.Cmat;
  
  fprintf(['Method ',cMethod,' : \t']);
  NTrials = 500;
  for iT = 1:size(CM.(cMethod),3)
    CMM = mean(CM.(cMethod)/NTrials,4);
    R.Performance.(cMethod)(iT) = mean(diag(CMM(:,:,iT)));
    fprintf([num2str(100*R.Performance.(cMethod)(iT),3),'%% ']);
  end
  fprintf('\n');
end
  
% LOAD PSTHs
BasePath = [Dirs.ITBarrel,'Data',Sep,'L4_PSTH',Sep];
Names = {'PW','2PW','1PW','SW'};
R.NStimuli = length(Names);
for iP = 1:length(Names)
  cFileName = [BasePath,'l4spt_',Names{iP},'_1.mat'];
  tmp = load(cFileName);
  M = cell2mat(tmp.spt_all);
  R.NTrials = length(tmp.spt_all);
  R.NNeurons = length(tmp.spt_all{1});
  M = M(:); M=M(M~=0)-40;
  R.TimeBins = [1:50]; % in ms
  R.L4_PSTHs{iP} = hist(M,R.TimeBins)/(R.NTrials*R.NNeurons)*1000;
  R.L4_SpikeTimesByTrial{iC}{iP} = tmp.spt_all;
end

save([inpath,name],'R')
  

function M = LF_transformData(C,SelInd)
 M = cell2mat(C);
 M = squeeze(M(1,:,:));
 M = reshape(M,[size(C{1},2),length(C),size(C{1},3)]);
 M = squeeze(M(SelInd,:,:));