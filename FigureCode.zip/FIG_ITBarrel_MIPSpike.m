function FIG_ITBarrel_MIPSpike(varargin)
  
%% PARSE ARGUMENTS
P = parsePairs(varargin);
checkField(P,'FIG',1); checkField(P,'Save',1);  checkField(P,'View',0);  checkField(P,'Recompute',0);  

% SETUP BASICS
Dirs = setgetDirs; cDir = Dirs.ITBarrel;
setPlotOpt('neuron','path',cDir,'cols',2,'height',10); 
Sep = HF_getSep;

if P.Recompute  LF_generateData(P.Recompute,inpath,name); end; load([inpath,name]);

% PREPARE FIGURE
figure(P.FIG); clf; set(P.FIG,FigOpt{:}); HF_matchAspectRatio;
DC = axesDivide([1,1,1,1],4,[0.12,0.1,0.75,0.8],[0.6,0.8,0.6],[0.6])';
DC2 = DC;
Labels = {'A','B','C','D','E','F','G','H','I','J','K','L'}; LdPos = [-0.04,0.015];
for i = 1:numel(DC)
  AH(i) = axes('Pos',DC{i}); hold on; FigLabel(Labels{i},LdPos); 
  DC2{i}(3) = DC2{i}(3)/3; DC2{i}(1) = DC2{i}(1)+DC{i}(3);
  AH2(i) = axes('Pos',DC2{i}); hold on;
end
HF_setFigProps;

% START PLOTTING 
%CM = HF_colormap({[1,1,1],[1,0,0]},[0,1]);
iA = 1;
colormap hot
XLabels = 'Neurons (#)'; YLabels = 'P_{spike}'; CLabels = 'MI (bits)';
GroupSizes = [1:R.NGroups];
ConditionNames = {'Pure Rate','Mixed','Pure Time'};

for iC = 1:length(R.Conditions)
  for iCC = 1:length(R.Codings)
    for iT = 1:length(R.CellTypes)  
      axes(AH(iA)); 
      if iCC*iT==1 text(-0.7,0.5,ConditionNames{iC},'Rotation',90,'FontSIze',8,'FontWeight','bold','Units','n','Horiz','center'); end
      if iC==1 text(0.5,1.15,R.CellTypes{iT},'FontSIze',8,'FontWeight','bold','Units','n','Horiz','center'); end
      if iC==1 && iT==1  text(1.3,1.35,R.Codings{iCC},'FontSIze',9,'FontWeight','bold','Units','n','Horiz','center'); end
      cData = R.(R.Conditions{iC}).(R.Codings{iCC}).(R.CellTypes{iT});
      dPSpike = 1/size(cData.MI,1);
      cPSpikes = [dPSpike/2,dPSpike,1-dPSpike/2];
      
      imagesc(GroupSizes,cPSpikes,cData.MI);
      set(gca,'YDir','normal','YTick',[0,1]);
      caxis([0,2]); box on; 
      axis([0,GroupSizes(end)+1,0,1]);
      if iC == length(R.Conditions) xlabel(XLabels); end;
      if iCC==2 && iT==2  
        h = colorbar('Location','East'); Pos = get(h,'Position');
        set(h,'YTick',[0,1,2],'Position',Pos+[0.08,0,0,0],'DataAspectRatio',HF_colorbarDAR(h,0.004),'YAxisLocation','right'); 
        text(1.8,0.5,CLabels,'Units','n','Rotation',90,'Horiz','c',AxisLabelOpt{:});      
      end;
      if iCC==1 && iT==1 ylabel(YLabels); end

      axes(AH2(iA)); axis off;
      NStimuli = size(cData.Hist,2);
      for i=1:NStimuli
        plot(cData.Hist(:,i),cData.Bins,'Color',[i/NStimuli,0,0],'LineWidth',1.5);
      end
      set(gca,'YTick',[],'XTick',[]);
      iA = iA +1;
    end
  end
end
HF_setFigProps;

% SAVE FIGURES
HF_viewsave('path',outpath,'name',[name],'view',P.View,'save',P.Save,'format','pdf','res',600);

function LF_generateData(Recompute,inpath,name)
  
Dirs = setgetDirs; Sep = HF_getSep;

R.Conditions = {'DRate_DTime','DRate_FTime','FRate_FTime','DRate_DTime_alpha75'};
R.Codings = {'Timing','Rate'};
R.CellTypes = {'Excitatory','Inhibitory'};
Vars = {'MI_E_fp','MI_I_fp'}; VarMatch = struct('MI_E_fp','Excitatory','MI_I_fp','Inhibitory');
SelIndsByCoding = [2,6];


% LOAD MIs
MethodInd = 1; PSpikeBins = [0.05:0.1:0.95];
for iC = 1:length(R.Conditions)
  cCondition = R.Conditions{iC};
  BasePath = [Dirs.ITBarrel,'Data',Sep,'Coding_',cCondition,Sep];
  for iCC = 1:2
    cCoding = R.Codings{iCC};
    cFileName = [BasePath,'Coding_',cCondition,'_1-100_classify_1stspike_SVM.mat'];
    tmp = load(cFileName,Vars{:},'fp_Econ_ind','fp_Icon_ind');
    cFileNameInfo = [BasePath,'Coding_',cCondition,'_allparameters.mat'];
    tmp2 = load(cFileNameInfo','l23info');
    for iT = 1:2
      % GET MI
      cType = R.CellTypes{iT};
      cTmp = tmp.(Vars{iT}); clear ccTmp
      R.NGroups = length(cTmp);
      for i=1:length(cTmp)
        if ~isempty(cTmp{i})
          ccTmp(:,i) = mean(squeeze(cTmp{i}(MethodInd,SelIndsByCoding(iCC),:,:)));
        end
      end
      R.(cCondition).(cCoding).(cType).MI = ccTmp;

      % GET HISTOGRAMS
      cVar = ['fp_',cType(1),'con_ind'];
      cData = tmp.(cVar);
      for i=1:size(cData,2)
        cH(:,i) = vertical(hist(cData(:,i),PSpikeBins));
        cH(:,i) = cH(:,i)/sum(cH(:,i));
      end
      R.(cCondition).(cCoding).(cType).Hist = cH;
      R.(cCondition).(cCoding).(cType).Bins = PSpikeBins;
    end
  end
end
save([inpath,name],'R')
